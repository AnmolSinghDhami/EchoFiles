package com.example.echo.activities

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.v4.app.FragmentActivity
import android.support.v4.app.NotificationCompat
import android.support.v4.app.NotificationManagerCompat
import android.support.v7.app.ActionBarDrawerToggle
import android.support.v4.widget.DrawerLayout
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.*
import android.widget.RemoteViews
import com.example.echo.CurrentSongHelper
import com.example.echo.R
import com.example.echo.activities.MainActivity.Statify.CHANNEL_ID
import com.example.echo.activities.MainActivity.Statify.NOTIFICATION_ID
import com.example.echo.activities.MainActivity.Statify.drawerLayout
import com.example.echo.activities.MainActivity.Statify.notificationManager
import com.example.echo.activities.MainActivity.Statify.notificationManagerCompat
import com.example.echo.adapters.NavigationDrawerAdapter
import com.example.echo.fragments.MainScreenFragment
import com.example.echo.fragments.PlayerFragment
import java.lang.Exception

class MainActivity : AppCompatActivity(){
    object Statify {
        var drawerLayout: DrawerLayout ?= null
        var notificationManager: NotificationManager ?= null
        val CHANNEL_ID: String = "ALl Notifications"
        val NOTIFICATION_ID: Int = 1
        var notificationManagerCompat: NotificationManagerCompat ?= null

        var currentSongHelper = CurrentSongHelper()
    }

    //var trackNotificationBuilder: NotificationCompat.Builder ?= null
    var trackNotificationBuilder: Notification?= null
    var navigationDrawerIconsList: ArrayList<String> = arrayListOf()
    var notification_layout: RemoteViews ?= null
    var images_For_Navdrawer: IntArray = intArrayOf(
        R.drawable.navigation_allsongs, R.drawable.navigation_favorites
        , R.drawable.navigation_settings, R.drawable.navigation_aboutus
    )

    override fun onCreate(savedInstanceState: Bundle?) {                                                                //onCreate
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        navigationDrawerIconsList.add("All Songs")
        navigationDrawerIconsList.add("Favorites")
        navigationDrawerIconsList.add("Settings")
        navigationDrawerIconsList.add("About Us")

        MainActivity.Statify.drawerLayout = findViewById(R.id.drawer_layout)
        val toggle = ActionBarDrawerToggle(
            this@MainActivity, MainActivity.Statify.drawerLayout, toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        MainActivity.Statify.drawerLayout?.setDrawerListener(toggle)
        toggle.syncState()

        val mainScreenFragment = MainScreenFragment()
        this.supportFragmentManager
            .beginTransaction()
            .add(R.id.details_fragment, mainScreenFragment, "MainScreenFragment")
            .commit()

        var navigation_recycler_view = findViewById<RecyclerView>(R.id.list)
        navigation_recycler_view.layoutManager = LinearLayoutManager(this)
        navigation_recycler_view.itemAnimator = DefaultItemAnimator()

        val _navigationAdapter = NavigationDrawerAdapter(navigationDrawerIconsList, images_For_Navdrawer, this)
        _navigationAdapter.notifyDataSetChanged()

        navigation_recycler_view.adapter = _navigationAdapter
        navigation_recycler_view.setHasFixedSize(true)
        val intent = Intent(this@MainActivity, MainActivity::class.java)
        val pIntent = PendingIntent.getActivity(this@MainActivity, System.currentTimeMillis().toInt(),
            intent, 0)
        Statify.notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel()
        notification_layout = RemoteViews(packageName, R.layout.notification_layout)


        //val playIntent = Intent()                                                                                        here!!!!!!!!
        //val pPlayIntent = PendingIntent.getBroadcast(this, 0, playIntent, 0)
        //notification_layout.setOnClickPendingIntent(R.id.notiPlay, pPlayIntent)




        val playIntent = Intent("com.example.echo.utils.PlayPause")
        val playPendingIntent = PendingIntent.getBroadcast(this@MainActivity, 90, playIntent, 0)
        notification_layout!!.setOnClickPendingIntent(R.id.notiPlay, playPendingIntent)

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            trackNotificationBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("A track is playing in the background")
                .setSmallIcon(R.drawable.echo_logo)
                .setContentIntent(pIntent)
                .setOngoing(true)
                .setChannelId(Statify.CHANNEL_ID)
                .setAutoCancel(true)
                //.setStyle(NotificationCompat.DecoratedCustomViewStyle())
                .setCustomContentView(notification_layout)
                .build()
        }
        else{
            trackNotificationBuilder = Notification.Builder(this)
                .setContentTitle("A track is playing in the background")
                .setSmallIcon(R.drawable.echo_logo)
                .setContentIntent(pIntent)
                .setOngoing(true)
                .setAutoCancel(true)
                .setSound(null)
                .build()
        }
        /*trackNotificationBuilder = Notification.Builder(this)
            .setContentTitle("A track is playing in the background")
            .setSmallIcon(R.drawable.echo_logo)
            .setContentIntent(pIntent)
            .setOngoing(true)
            .setAutoCancel(true)
            .build()*/
        /*trackNotificationBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("A track is playing in the background")
            .setSmallIcon(R.drawable.echo_logo)
            .setContentIntent(pIntent)
            .setOngoing(true)
            .setAutoCancel(true)
            .build() as NotificationCompat.Builder*/

        //trackNotificationBuilder

    }

    fun updateNotificationText(){
        if (PlayerFragment.Statified.currentSongHelper != null){
            Statify.currentSongHelper = PlayerFragment.Statified.currentSongHelper as CurrentSongHelper
        }
        notification_layout?.setTextViewText(R.id.notificationSongTitle, Statify.currentSongHelper?.songTitle)
        notification_layout?.setTextViewText(R.id.notificationArtist, Statify.currentSongHelper?.songArtist)
    }

    fun createNotificationChannel(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val name: String = "All"
            val descriptionText: String = "Includes music player notifications"
            val importance: Int = NotificationManager.IMPORTANCE_DEFAULT
            val notificationChannel = NotificationChannel(Statify.CHANNEL_ID, name, importance)
            notificationChannel.setSound(null, null)
            //Statify.notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            Statify.notificationManager?.createNotificationChannel(notificationChannel)
        }
    }

    override fun onStart() {                                                                                            //onStart
        super.onStart()
        try {
            notificationManager?.cancel(NOTIFICATION_ID)
        }
        catch (e: Exception){
            e.printStackTrace()
        }
    }

    override fun onStop() {
        super.onStop()
        try{
            if (PlayerFragment.Statified.mediaPlayer?.isPlaying as Boolean){
                updateNotificationText()
                //Statify.notificationManager?.notify(123, trackNotificationBuilder)
                notificationManager?.notify(NOTIFICATION_ID, trackNotificationBuilder as Notification)

            }
        }
        catch (e: Exception){
            e.printStackTrace()
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            notificationManager?.cancel(NOTIFICATION_ID)
        }
        catch (e: Exception){
            e.printStackTrace()
        }
    }
}

