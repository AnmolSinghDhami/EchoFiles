package com.example.echo.databases

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Parcel
import android.os.Parcelable
import android.widget.Toast
import com.example.echo.Songs
import java.lang.Exception
import java.lang.NullPointerException

class ShufflePlusDatabase : SQLiteOpenHelper {

    object Staticated {
        var DB_VERSION = 1
        val DB_NAME = "ShuffleDatabase"
        val TABLE_NAME = "ShuffleTable"
        val COLUMN_ID = "SongID"
        val COLUMN_SONG_TITLE = "SongTitle"
        val COLUMN_SONG_ARTIST = "SongArtist"
        val COLUMN_SONG_SCORE = "SongScore"
        var curId = 0
        var scores: ArrayList<Int>? = null
    }

    override fun onCreate(sqliteDatabase: SQLiteDatabase?) {
        sqliteDatabase?.execSQL(
            "CREATE TABLE " + Staticated.TABLE_NAME + "( " + Staticated.COLUMN_ID + " INTEGER, "
                    + Staticated.COLUMN_SONG_TITLE + " STRING, " + Staticated.COLUMN_SONG_ARTIST + " STRING, "
                    + Staticated.COLUMN_SONG_SCORE + " INTEGER);"
        )
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {

    }

    constructor(context: Context?, name: String?, factory: SQLiteDatabase.CursorFactory?, version: Int) : super(
        context,
        name,
        factory,
        version
    )

    constructor(context: Context?) : super(context, Staticated.DB_NAME, null, Staticated.DB_VERSION)

    fun readFromShuffle() {
        val db = this.readableDatabase
        val query = "SELECT * FROM " + Staticated.TABLE_NAME
        val cSor = db.rawQuery(query, null)
        if (cSor.moveToFirst()) {
            do {
                val _score = cSor.getInt(cSor.getColumnIndexOrThrow(Staticated.COLUMN_SONG_SCORE))
                Staticated.scores?.add(_score)
            } while (cSor.moveToNext())
            Staticated.curId = Staticated.scores?.size as Int
        }
    }


}