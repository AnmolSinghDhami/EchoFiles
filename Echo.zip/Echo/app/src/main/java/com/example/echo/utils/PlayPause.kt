package com.example.echo.utils

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.echo.fragments.PlayerFragment


class PlayPause: BroadcastReceiver() {
    override fun onReceive(p0: Context?, p1: Intent?) {
        PlayerFragment.Statified.mediaPlayer?.pause()
    }

}