package com.example.echo.fragments

import android.app.Activity
import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.*
import android.widget.Button
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import com.example.echo.R
import com.example.echo.Songs
import com.example.echo.adapters.MainScreenAdapter
import com.example.echo.databases.EchoDatabase
import com.example.echo.databases.ShufflePlusDatabase
import java.util.*
import kotlin.collections.ArrayList


/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [MainScreenFragment.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [MainScreenFragment.newInstance] factory method to
 * create an instance of this fragment.
 *
 */
class MainScreenFragment : Fragment() {
    var getSongsList:ArrayList<Songs> ?= null
    var nowPlayingBottomBar: RelativeLayout ?= null
    var playPauseButton: ImageView ?= null
    var songTitle: TextView ?= null
    var visibleLayout: RelativeLayout ?= null
    var noSongs: RelativeLayout ?= null
    var recyclerView: RecyclerView ?= null
    var myActivity: Activity ?= null
    var _mainScreenAdapter: MainScreenAdapter ?= null
    var trackPosition: Int = 0
    var shuffleAdd: EchoDatabase ?= null


    object Statified{
        var mediaPlayer: MediaPlayer ?= null
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
            activity?.title = "All Songs"
            val view = inflater.inflate(R.layout.fragment_main_screen, container, false)
            visibleLayout = view?.findViewById(R.id.visibleLayout)
            noSongs = view?.findViewById(R.id.noSongs)
            nowPlayingBottomBar = view?.findViewById(R.id.hiddenBarMainScreen)
            songTitle = view?.findViewById(R.id.songTitleMainScreen)
            playPauseButton = view?.findViewById(R.id.playPauseButton)
            recyclerView = view?.findViewById(R.id.contentMain)
            setHasOptionsMenu(true)


        return view
    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        menu?.clear()
        inflater?.inflate(R.menu.main, menu)
        return
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val switcher = item?.itemId
        if(switcher == R.id.action_sort_ascending){
            val editor = myActivity?.getSharedPreferences("action_sort", Context.MODE_PRIVATE)?.edit()
            editor?.putString("action_sort_ascending", "true")
            editor?.putString("action_sort_recent", "false")
            editor?.apply()
            if (getSongsList != null){
                Collections.sort(getSongsList, Songs.Statified.nameComparator)
            }
            _mainScreenAdapter?.notifyDataSetChanged()
            return false
        }
        else if (switcher == R.id.action_sort_recent){
            val editortwo = myActivity?.getSharedPreferences("action_sort", Context.MODE_PRIVATE)?.edit()
            editortwo?.putString("action_sort_recent", "true")
            editortwo?.putString("action_sort_ascending", "false")
            editortwo?.apply()
            if (getSongsList != null){
                Collections.sort(getSongsList, Songs.Statified.dateComparator)
            }
            _mainScreenAdapter?.notifyDataSetChanged()
            return false
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        shuffleAdd = EchoDatabase(myActivity)
        getSongsList = getSongsFromPhone()
        if (getSongsList == null){
            visibleLayout?.visibility = View.INVISIBLE
            noSongs?.visibility = View.INVISIBLE
        }
        else{
            _mainScreenAdapter = MainScreenAdapter(getSongsList as ArrayList<Songs>, myActivity as Context)
            val mLayoutManager = LinearLayoutManager(myActivity)
            recyclerView?.layoutManager = mLayoutManager
            recyclerView?.itemAnimator = DefaultItemAnimator()
            recyclerView?.adapter = _mainScreenAdapter
        }
        val prefs = activity?.getSharedPreferences("action_sort", Context.MODE_PRIVATE)
        val action_sort_ascending = prefs?.getString("action_sort_ascending", "true")
        val action_sort_recent = prefs?.getString("action_sort_recent", "false")
        if (getSongsList != null){
            if (action_sort_ascending!!.equals("true", true)){
                Collections.sort(getSongsList, Songs.Statified.nameComparator)
                _mainScreenAdapter?.notifyDataSetChanged()
            }
            else if (action_sort_recent!!.equals("true", true)) {
                Collections.sort(getSongsList, Songs.Statified.dateComparator)
                _mainScreenAdapter?.notifyDataSetChanged()
            }
        }
        bottomBarSetup()
    }

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        myActivity = context as Activity
    }

    override fun onAttach(activity: Activity?) {
        super.onAttach(activity)
        myActivity = activity
    }

    fun getSongsFromPhone(): ArrayList<Songs>{
        shuffleAdd?.checkIdShuffle()
        var arrayList = arrayListOf<Songs>()
        var contentResolver = myActivity?.contentResolver
        var songUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        var songCursor = contentResolver?.query(songUri, null, null, null, null)
        if (songCursor != null && songCursor.moveToFirst()){
            val songId = songCursor.getColumnIndex(MediaStore.Audio.Media._ID)
            val songTitle = songCursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
            val songArtist = songCursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
            val songData = songCursor.getColumnIndex(MediaStore.Audio.Media.DATA)
            val dateIndex = songCursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
            while (songCursor.moveToNext()){
                var currentId = songCursor.getLong(songId)
                var currentTitle = songCursor.getString(songTitle)
                if (currentTitle.equals("<unknown>", true)){
                    currentTitle = "Unknown"
                }
                var currentArtist = songCursor.getString(songArtist)
                if (currentArtist.equals("<unknown>", true)){
                    currentArtist = "Unknown"
                }
                var currentData = songCursor.getString(songData)
                var currentDate = songCursor.getLong(dateIndex)
                arrayList.add(Songs(currentId, currentTitle, currentArtist, currentData, currentDate))
                shuffleAdd?.addToShuffle(currentTitle, currentArtist)
            }
        }
        return arrayList
    }

    fun bottomBarSetup(){
        try{
            bottomBarClickHandler()
            songTitle?.setText(PlayerFragment.Statified.currentSongHelper?.songTitle)
            PlayerFragment.Statified.mediaPlayer?.setOnCompletionListener {
                songTitle?.setText(PlayerFragment.Statified.currentSongHelper?.songTitle)
                PlayerFragment.Staticated.onSongComplete()
            }
            if(PlayerFragment.Statified.mediaPlayer?.isPlaying as Boolean){
                nowPlayingBottomBar?.visibility = View.VISIBLE
            }
            else{
                nowPlayingBottomBar?.visibility = View.INVISIBLE
            }
        }
        catch(e: Exception){
            e.printStackTrace()
        }
    }

    fun bottomBarClickHandler(){
        nowPlayingBottomBar?.setOnClickListener {
            Statified.mediaPlayer = PlayerFragment.Statified.mediaPlayer
            val songPlayingFragment = PlayerFragment()
            var args = Bundle()
            args.putString("songArtist", PlayerFragment.Statified.currentSongHelper?.songArtist)
            args.putString("path", PlayerFragment.Statified.currentSongHelper?.songPath)
            args.putString("songTitle", PlayerFragment.Statified.currentSongHelper?.songTitle)
            args.putInt("songId", PlayerFragment.Statified.currentSongHelper?.songId?.toInt() as Int)
            args.putInt("songPosition", PlayerFragment.Statified.currentSongHelper?.currentPosition?.toInt() as Int)
            args.putParcelableArrayList("songData", PlayerFragment.Statified.fetchSongs)
            args.putString("MainScreenBottomBar", "success")
            songPlayingFragment.arguments = args
            fragmentManager?.beginTransaction()                                                                             //!! or ?
                ?.replace(R.id.details_fragment, songPlayingFragment)
                ?.addToBackStack("SongsPlayingFragmentMain")
                ?.commit()
        }
        playPauseButton?.setOnClickListener{
            if (PlayerFragment.Statified.mediaPlayer?.isPlaying as Boolean){
                PlayerFragment.Statified.mediaPlayer?.pause()
                trackPosition = PlayerFragment.Statified.mediaPlayer?.getCurrentPosition() as Int
                playPauseButton?.setBackgroundResource(R.drawable.play_icon)
            }
            else{
                PlayerFragment.Statified.mediaPlayer?.seekTo(trackPosition)
                PlayerFragment.Statified.mediaPlayer?.start()
                playPauseButton?.setBackgroundResource(R.drawable.pause_icon)
            }
        }
    }

}
